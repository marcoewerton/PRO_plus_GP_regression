## This script allows the user to control the human.
## Our framework computes the movements of the robot.

from __future__ import print_function
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import animation
import myClasses as mC
import seaborn as sns
sns.set()



############################# Functions #################################



############################# Main code ##################################

n_dof = 2

# Load learned model
learned_model_folder = "Learned_Model"
known_envs = np.load(learned_model_folder + '/known_envs.npy')
ke_characteristic_vectors = np.load(learned_model_folder + '/ke_characteristic_vectors.npy')
known_envs_groups = np.load(learned_model_folder + '/known_envs_groups.npy')
really_known_envs = np.load(learned_model_folder + '/really_known_envs.npy')
rke_characteristic_vectors = np.load(learned_model_folder + '/rke_characteristic_vectors.npy')
really_known_envs_groups = np.load(learned_model_folder + '/really_known_envs_groups.npy')
unknown_envs = np.load(learned_model_folder + '/unknown_envs.npy')
ue_characteristic_vectors = np.load(learned_model_folder + '/ue_characteristic_vectors.npy')
unknown_envs_groups = np.load(learned_model_folder + '/unknown_envs_groups.npy')
known_mean_weights = np.load(learned_model_folder + '/known_mean_weights.npy')
really_known_mean_weights = np.load(learned_model_folder + '/really_known_mean_weights.npy')
known_var_weights = np.load(learned_model_folder + '/known_var_weights.npy')
really_known_var_weights = np.load(learned_model_folder + '/really_known_var_weights.npy')
mu = np.load(learned_model_folder + '/mu.npy')
noise_var = np.load(learned_model_folder + '/noise_var.npy')
max_length = np.load(learned_model_folder + '/max_length.npy')
block_PSI = np.load(learned_model_folder + '/block_PSI.npy')
num_gaba = np.load(learned_model_folder + '/num_gaba.npy')
unsolved_envs = np.load(learned_model_folder + '/unsolved_envs.npy')
unsolved_envs_indexes = np.load(learned_model_folder + '/unsolved_envs_indexes.npy')
unsolved_envs_groups = np.load(learned_model_folder + '/unsolved_envs_groups.npy')


corners = np.array([[0, 0], [10, 0], [10, 10], [0, 10]])

fig, ax = plt.subplots(figsize=(7, 7))
plt.axis('scaled')
ax.set_xlim(-3, 13)
ax.set_ylim(-3, 13)

# Draw walls
ax.plot([corners[0, 0], corners[1, 0]], [corners[0, 1], corners[1, 1]], linewidth=2.0, color="b")
ax.plot([corners[1, 0], corners[2, 0]], [corners[1, 1], corners[2, 1]], linewidth=2.0, color="b")
ax.plot([corners[2, 0], corners[3, 0]], [corners[2, 1], corners[3, 1]], linewidth=2.0, color="b")
ax.plot([corners[3, 0], corners[0, 0]], [corners[3, 1], corners[0, 1]], linewidth=2.0, color="b")

# Initialize human
h_center = np.array([2., 2.])
h_radius = 0.25
h_color = "r"
h_angle = 0.
h_dist_to_target = 2.
human = mC.Human(h_center, h_radius, h_color, h_angle, h_dist_to_target, ax, corners)

# Initialize robot
r_center = np.array([5., 5.])
r_radius = 0.25
r_color = "g"
r_angle = 0.
r_arrow_length = 1.
max_step_size = 0.1
# max_step_size = 1
robot = mC.Robot(r_center, r_radius, r_color, r_angle, r_arrow_length, ax, corners, max_step_size)

# Initialize mouse
mouse = mC.Mouse(ax)

# Initialize animator
animator = mC.Animator(human, robot, mouse, ke_characteristic_vectors, known_envs, known_mean_weights, known_var_weights, known_envs_groups, n_dof, num_gaba, block_PSI, max_length, testing=True)

cid = fig.canvas.mpl_connect('motion_notify_event', mouse.update_mouse_position)
cid = fig.canvas.mpl_connect('button_press_event', mouse.update_mouse_position)

anim = animation.FuncAnimation(fig, animator.animate,
                               init_func=animator.init,
                               frames=100000,
                               interval=50,
                               blit=True)

plt.show()