import numpy as np
import ProMP as pmp
import matplotlib.pyplot as plt

def learn_promp(num_gaba, n_demonstrated_envs, n_demonstrations_per_env):

    dem_envs = np.load('dem_envs/dem_envs.npy')

    # load demonstrated trajectories
    demonstrations = []  # A list of ndarrays
    for i in range(n_demonstrated_envs):
        # if i == 4:
        #     print(dem_envs[i, :])

        human_xy = dem_envs[i, 0:2]
        robot_xy = dem_envs[i, 3:5]
        robot_to_human = human_xy - robot_xy
        rotation_angle = 0
        if robot_to_human[0] >= 0 and robot_to_human[1] >= 0:
            pass
        elif robot_to_human[0] < 0 and robot_to_human[1] >= 0:
            rotation_angle = -np.pi/2
        elif robot_to_human[0] <= 0 and robot_to_human[1] < 0:
            rotation_angle = -np.pi
        elif robot_to_human[0] > 0 and robot_to_human[1] < 0:
            rotation_angle = np.pi/2

        A = np.array([[np.cos(rotation_angle), -np.sin(rotation_angle)], [np.sin(rotation_angle), np.cos(rotation_angle)]])

        for j in range(n_demonstrations_per_env):
            tmp = np.load("demonstrations/dem_{}_{}.npy".format(i, j))

            # Make demonstration start at (0, 0)
            tmp = tmp - tmp[0, :]

            # Rotate demonstration such that it ends up as if the human were in the 1st quadrant (x >= 0, y >= 0)
            rot_tmp = np.dot(A, tmp.T)

            # fig, ax = plt.subplots()
            # ax.scatter(human_xy[0] - robot_xy[0], human_xy[1] - robot_xy[1], color='r')
            # ax.scatter(0, 0, color='g')
            # ax.plot(tmp[:, 0], tmp[:,1], 'b')
            # plt.show()

            demonstrations.append(rot_tmp.T)

    # learn ProMP
    myProMP = pmp.ProMP(demonstrations, num_gaba)  # The trajectories in demonstrations are time-aligned by ProMP.

    return myProMP
