from time import sleep
import tkinter as tk

root = tk.Tk()
#root.withdraw()  # Do not show root window.
spacedown = False


def press_s(dummy):
    global spacedown
    spacedown = True
    print('down')


def release_s(dummy):
    global spacedown
    spacedown = False
    print('up')


root.bind('<KeyPress- >', press_s)
root.bind('<KeyRelease- >', release_s)
while True:
    sleep(1)
    root.update()
    print('tick', 'down' if spacedown else 'up')