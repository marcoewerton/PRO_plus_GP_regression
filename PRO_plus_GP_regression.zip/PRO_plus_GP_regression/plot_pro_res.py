import numpy as np
import matplotlib.pyplot as plt

# Plots rewards and dists over iterations of PRO
def plot(n_objectives, n_iter, max_len, learnt_pol):

    # Plot PRO iterations versus returns
    for i in range(n_objectives):
        fig1 = plt.figure()
        fig1.set_size_inches(4, 3)
        ax1 = fig1.add_subplot(111)
        mu_obj_val = np.mean(learnt_pol.all_objective_vals[i], axis=0)
        std_obj_val = np.std(learnt_pol.all_objective_vals[i], axis=0)
        ax1.plot(mu_obj_val)
        ax1.fill_between(range(n_iter), mu_obj_val - 2.0 * std_obj_val, mu_obj_val + 2.0 * std_obj_val,
                         alpha=0.5)
        ax1.set_xlabel('Iteration')
        ax1.set_ylabel('Objective Value')
        ax1.grid(True)
        plt.title("Objective " + str(i) + " vs. Iterations")
        plt.show()