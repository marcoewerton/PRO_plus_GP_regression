import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from numpy.linalg import inv


class Human:

    def __init__(self, center_, radius_, color_, angle_, dist_to_target_, ax_, corners_, step_=0.1):
        self.center = center_
        self.radius = radius_
        self.color = color_
        self.angle = angle_
        self.dist_to_target = dist_to_target_
        self.axes = ax_
        self.min_x = corners_[0, 0]
        self.min_y = corners_[0, 1]
        self.max_x = corners_[1, 0]
        self.max_y = corners_[2, 1]
        self.step = step_
        self.circle = plt.Circle(self.center, radius=self.radius, color=self.color)
        self.line = None
        self.target = None
        self.target_marker = None

    def translate(self):
        dx = self.step * np.cos(self.angle)
        dy = self.step * np.sin(self.angle)
        self.center = self.center + np.array([dx, dy])
        if self.center[0] < self.min_x or self.center[0] > self.max_x or self.center[1] < self.min_y or self.center[1] > self.max_y:
            self.center = self.center - np.array([dx, dy])

    def get_target(self):
        target_x = self.center[0] + self.dist_to_target * np.cos(self.angle)
        target_y = self.center[1] + self.dist_to_target * np.sin(self.angle)
        self.target = np.array([target_x, target_y])
        return self.target


class Robot:

    def __init__(self, center_, radius_, color_, angle_, arrow_length_, ax_, corners_, max_step_):
        self.center = center_
        self.radius = radius_
        self.color = color_
        self.angle = angle_
        self.axes = ax_
        self.arrow_length = arrow_length_
        self.min_x = corners_[0, 0]
        self.min_y = corners_[0, 1]
        self.max_x = corners_[1, 0]
        self.max_y = corners_[2, 1]
        self.max_step = max_step_
        self.circle = plt.Circle(self.center, radius=self.radius, color=self.color)
        self.arrow = None
        self.press = None
        self.trajectory = []
        # self.draw_trajectory = False

    def on_press(self, event):
        if event.inaxes != self.axes: return
        contains, attrd = self.circle.contains(event)
        if not contains: return
        x0, y0 = self.center
        self.press = x0, y0, event.xdata, event.ydata
        self.trajectory.append([x0, y0])

    def on_motion(self, event):
        if self.press is None: return
        if event.inaxes != self.axes: return
        x0, y0, xpress, ypress = self.press
        dx = event.xdata - xpress
        dy = event.ydata - ypress
        self.center = np.array([x0+dx, y0+dy])
        self.trajectory.append([x0+dx, y0+dy])

    def on_release(self, event):
        self.press = None
        # self.draw_trajectory = True


class Mouse:

    def __init__(self, ax_):
        self.axes = ax_
        self.mouse_position = None

    def update_mouse_position(self, event):
        if event.inaxes != self.axes: return
        self.mouse_position = (event.xdata, event.ydata)


class Animator:

    def __init__(self, human_, robot_, mouse_, ke_characteristic_vectors_=None, known_envs_=None, known_mean_weights_=None, known_var_weights_=None, known_envs_groups_=None, n_dof_=None, num_gaba_=None, block_PSI_=None, max_length_=None, trajectory=None, testing=False):
        self.human = human_
        self.robot = robot_
        self.mouse = mouse_
        self.ke_characteristic_vectors = ke_characteristic_vectors_
        self.known_envs = known_envs_
        self.known_mean_weights = known_mean_weights_
        self.known_var_weights = known_var_weights_
        self.known_envs_groups = known_envs_groups_
        self.n_dof = n_dof_
        self.num_gaba = num_gaba_
        self.block_PSI = block_PSI_
        self.max_length = max_length_
        self.trajectory = trajectory  # This variable is only to execute previously defined trajectories
                                       # or inferred trajectories.
        self.robot_path = self.robot.center.reshape((1, 2))  # this variable is to store the path that I want to draw
        self.robot_path_line = None  # this variable will represent a line returned by plt.plot
        self.robot_planned_path = self.robot.center.reshape((1, 2))
        self.robot_planned_path_line = None
        self.testing = testing
        self.index_execute_trajectory = 0
        self.index_testing = 0
        self.robot_to_current_goal = None

        self.previous_target = None
        self.env_changed = True

    def init(self):
        self.human.axes.add_patch(self.human.circle)
        self.human.target = self.human.get_target()
        self.previous_target = np.copy(self.human.target)
        # print('Human angle: {}'.format(self.human.angle))
        # print('Human center: {}'.format(self.human.center))
        # print('Target: {}'.format(target))
        self.human.line, = plt.plot([self.human.center[0], self.human.target[0]], [self.human.center[1], self.human.target[1]], linestyle=':', color='k')
        self.human.target_marker, = plt.plot([self.human.target[0]], [self.human.target[1]], color='k', marker='x', markeredgewidth='2', markersize=10)
        if not self.testing:
            self.robot_path_line, = plt.plot([self.robot_path[:, 0]], [self.robot_path[:, 1]], color='0.7')
        else:
            self.robot_planned_path_line, = plt.plot([self.robot_path[:, 0]], [self.robot_path[:, 1]], color='b')

        self.robot.axes.add_patch(self.robot.circle)

        dx = self.robot.arrow_length * np.cos(self.robot.angle)
        dy = self.robot.arrow_length * np.sin(self.robot.angle)
        x_tail, y_tail = self.robot.center
        self.robot.arrow = mpatches.FancyArrowPatch((x_tail, y_tail), (dx, dy), mutation_scale=15, color='k')
        self.robot.axes.add_patch(self.robot.arrow)

        if not self.testing:
            return self.human.circle, self.human.line, self.human.target_marker, self.robot_path_line, self.robot.circle, self.robot.arrow,
        else:
            return self.human.circle, self.human.line, self.human.target_marker, self.robot.circle, self.robot.arrow,

        # return self.human.circle, self.human.line, self.human.target_marker, self.robot_path_line, self.robot.circle, self.robot.arrow,


    def animate(self, i):
        if self.mouse.mouse_position is not None:
            human_to_mouse_x = self.mouse.mouse_position[0] - self.human.center[0]
            human_to_mouse_y = self.mouse.mouse_position[1] - self.human.center[1]
            self.human.angle = np.arctan2(human_to_mouse_y, human_to_mouse_x)
            if np.linalg.norm(np.array([human_to_mouse_x, human_to_mouse_y])) > self.human.step/2:  # If the distance is smaller than the half of the step size, making a step does not pay off.
                self.human.translate()
                self.human.target = self.human.get_target()
                if not np.array_equal(self.human.target, self.previous_target):
                    self.env_changed = True
                    self.previous_target = np.copy(self.human.target)

        self.human.circle.center = self.human.center

        self.human.line.set_data([self.human.center[0], self.human.target[0]], [self.human.center[1], self.human.target[1]])
        # print('Target: {}'.format(target))
        # print('Human_center: {}'.format(self.human.center))
        self.human.target_marker.set_data([self.human.target[0]], [self.human.target[1]])

        ######################## If in testing mode, infer the trajectory of the robot #################################
        if self.testing and self.env_changed:
            new_mean_weights = np.zeros((self.n_dof * self.num_gaba, 1))
            new_var_weights = np.zeros((self.n_dof * self.num_gaba, 1))

            robot_to_human_original = self.human.center - self.robot.center
            robot_to_human = np.copy(robot_to_human_original)
            human_theta = self.human.angle
            rotation_angle = 0
            # Adjust the x,y coordinates and the angle of the human
            if robot_to_human_original[0] >= 0 and robot_to_human_original[1] >= 0:
                pass
            elif robot_to_human_original[0] < 0 and robot_to_human_original[1] >= 0:
                rotation_angle = -(np.pi/2)
            elif robot_to_human_original[0] <= 0 and robot_to_human_original[1] < 0:
                rotation_angle = -np.pi
            elif robot_to_human_original[0] > 0 and robot_to_human_original[1] < 0:
                rotation_angle = np.pi/2

            human_theta += rotation_angle
            A = np.array([[np.cos(rotation_angle), -np.sin(rotation_angle)], [np.sin(rotation_angle), np.cos(rotation_angle)]])
            robot_to_human = np.dot(A, robot_to_human.reshape((2, 1))).reshape(-1, )
            new_env = np.hstack((robot_to_human, human_theta))

            ne_characteristic_vector = self.get_characteristic_vector(new_env)

            ## Figure out if the object is to the left or to the right of the direct path to the goal
            new_env_group = self.what_group(new_env)

            ## Find the closest envs
            tmp_known_envs, tmp_known_mean_weights, tmp_known_var_weights, tmp_mu, tmp_noise_var = self.find_closest_envs(
                self.ke_characteristic_vectors, self.known_envs, self.known_mean_weights, self.known_var_weights, new_env, new_env_group,
                self.known_envs_groups)

            tmp_ke_characteristic_vectors = np.zeros((4, tmp_known_envs.shape[1]))
            for j in range(tmp_known_envs.shape[1]):
                tmp_ke_characteristic_vector = self.get_characteristic_vector(tmp_known_envs[:, j])
                tmp_ke_characteristic_vectors[:, j] = tmp_ke_characteristic_vector

            for w_index in range(self.n_dof * self.num_gaba):  # There is one GP for each weight
                Caa, Cab, Cba, Cbb = self.compute_cov_matrix(ne_characteristic_vector, tmp_ke_characteristic_vectors)
                yb = tmp_known_mean_weights[w_index, :].reshape(tmp_known_envs.shape[1], 1)
                w_var_matrix = np.diag(tmp_known_var_weights[w_index, :])
                # Inference
                m = tmp_mu[w_index] + Cab @ inv(Cbb + w_var_matrix) @ (
                            yb - tmp_mu[w_index])  # mu_a = mu_b = mu[w_index]
                D = Caa + tmp_noise_var[w_index] - Cab @ inv(Cbb + w_var_matrix) @ Cba
                new_mean_weights[w_index] = m
                new_var_weights[w_index] = D

            # compute mean trajectory of posterior
            mean_trajectory = np.dot(new_mean_weights.reshape(-1, ), np.transpose(self.block_PSI))
            mean_trajectory = mean_trajectory.reshape(1, -1)

            self.trajectory = np.hstack((mean_trajectory[0, 0:self.max_length].reshape(-1, 1), mean_trajectory[0, self.max_length:2 * self.max_length].reshape(-1, 1)))

            # rotate the trajectory
            rotation_angle = 0
            if robot_to_human_original[0] >= 0 and robot_to_human_original[1] >= 0:
                pass
            elif robot_to_human_original[0] < 0 and robot_to_human_original[1] >= 0:
                rotation_angle = np.pi / 2
            elif robot_to_human_original[0] <= 0 and robot_to_human_original[1] < 0:
                rotation_angle = np.pi
            elif robot_to_human_original[0] > 0 and robot_to_human_original[1] < 0:
                rotation_angle = -np.pi / 2
            A = np.array([[np.cos(rotation_angle), -np.sin(rotation_angle)], [np.sin(rotation_angle), np.cos(rotation_angle)]])
            rot_trajectory = np.dot(A, self.trajectory.T)
            self.trajectory = rot_trajectory.T

            # translate trajectory such that it starts at the current position of the robot
            self.trajectory = self.trajectory + self.robot.center

        ################################################################################################################

        if self.trajectory is None:
            self.robot.circle.center = self.robot.center
        elif not self.testing:
            self.robot.center = self.trajectory[self.index_execute_trajectory]
            self.robot.circle.center = self.robot.center
            if self.index_execute_trajectory < self.trajectory.shape[0] - 1:
                self.index_execute_trajectory += 1
            else:
                print('Execution finished')
                self.trajectory = None
        else:  # If it's a test (if the robot is supposed to move autonomously)
            # print("Here")
            # print(np.linalg.norm(self.human.target - self.robot.center))
            if self.env_changed is True:
                for self.index_testing in range(self.max_length):
                    self.robot_to_current_goal = self.trajectory[self.index_testing] - self.robot.center
                    magnitude = np.linalg.norm(self.robot_to_current_goal)
                    if magnitude > self.robot.max_step:
                        self.robot_to_current_goal = (self.robot_to_current_goal/magnitude)*self.robot.max_step
                        break
            else:
                while self.index_testing < self.trajectory.shape[0] - 1:
                    self.index_testing += 1
                    self.robot_to_current_goal = self.trajectory[self.index_testing] - self.robot.center
                    magnitude = np.linalg.norm(self.robot_to_current_goal)
                    if magnitude > self.robot.max_step:
                        self.robot_to_current_goal = (self.robot_to_current_goal / magnitude) * self.robot.max_step
                        self.index_testing -= 1
                        break
                if self.index_testing == self.trajectory.shape[0] - 1:
                    self.robot_to_current_goal = 0

        # print(self.robot_to_current_goal)
        # print(self.index_testing)
        self.robot.center = self.robot.center + self.robot_to_current_goal
        self.robot.circle.center = self.robot.center

        self.env_changed = False

        self.robot_path = np.vstack((self.robot_path, self.robot.center.reshape((1,2))))
        if not self.testing:
            self.robot_path_line.set_data([self.robot_path[:, 0]], [self.robot_path[:, 1]])
        else:
            self.robot_planned_path_line.set_data(self.trajectory[:, 0], self.trajectory[:, 1])

        robot_to_human_x = self.human.center[0] - self.robot.center[0]
        robot_to_human_y = self.human.center[1] - self.robot.center[1]
        self.robot.angle = np.arctan2(robot_to_human_y, robot_to_human_x)
        dx = self.robot.arrow_length * np.cos(self.robot.angle)
        dy = self.robot.arrow_length * np.sin(self.robot.angle)
        self.robot.arrow.set_positions((self.robot.center[0], self.robot.center[1]), (self.robot.center[0] + dx, self.robot.center[1] + dy))

        # if self.robot.draw_trajectory is True:
        #     return self.human.circle, self.human.line, self.human.target_marker, self.robot_path_line, self.robot.circle, self.robot.arrow,
        #     self.robot.draw_trajectory = False
        # else:
        #     return self.human.circle, self.human.line, self.human.target_marker, self.robot.circle, self.robot.arrow,

        if not self.testing:
            return self.human.circle, self.human.line, self.human.target_marker, self.robot_path_line, self.robot.circle, self.robot.arrow,
        else:
            return self.human.circle, self.human.line, self.human.target_marker, self.robot_planned_path_line, self.robot.circle, self.robot.arrow,

        # return self.human.circle, self.human.line, self.human.target_marker, self.robot_path_line, self.robot.circle, self.robot.arrow,

    # Function to compute the characteristic vector of an environment
    # The characteristic vector of an environment is the concatenation of the vectors robot_to_human
    # and robot_to_target
    def get_characteristic_vector(self, env):
        robot_pos = np.array([0, 0])
        human_xy = env[0:2]
        human_theta = env[-1]
        target = self.get_target(human_xy[0], human_xy[1], human_theta)

        robot_to_human = human_xy - robot_pos
        robot_to_target = target - robot_pos

        characteristic_vector = np.hstack((robot_to_human, robot_to_target))

        return characteristic_vector

    def get_target(self, hx, hy, htheta, dist_to_target=2):
        target_x = hx + dist_to_target * np.cos(htheta)
        target_y = hy + dist_to_target * np.sin(htheta)
        target = np.array([target_x, target_y])
        return target

    # Function to determine the group of the environment. There are two groups: 1) The human is to the left of the direct path to the target.
    # 2) The human is to the right of the direct path to the target.
    def what_group(self, env):
        robot_pos = np.array([0, 0])
        human_xy = env[0:2]
        human_theta = env[-1]
        target = self.get_target(human_xy[0], human_xy[1], human_theta)

        robot_to_human = human_xy - robot_pos
        robot_to_target = target - robot_pos

        cross_product = np.cross(robot_to_target, robot_to_human)

        if cross_product >= 0:
            return 1
        else:
            return 2

    # Function to find the N closest known environments to a given environment
    def find_closest_envs(self, ke_characteristic_vectors, known_envs, known_mean_weights, known_var_weights, new_env,
                          new_env_group, known_envs_groups, N=30):

        ne_characteristic_vector = self.get_characteristic_vector(new_env)

        diffs = ke_characteristic_vectors - ne_characteristic_vector.reshape(-1, 1)
        dists = np.linalg.norm(diffs, axis=0)

        dists[np.array(known_envs_groups) != new_env_group] = np.Inf

        indices = np.argsort(dists)

        tmp_known_envs = known_envs[:, indices[:N]]
        tmp_known_mean_weights = known_mean_weights[:, indices[:N]]
        tmp_known_var_weights = known_var_weights[:, indices[:N]]

        tmp_mu = np.mean(tmp_known_mean_weights, axis=1)
        tmp_noise_var = np.mean(tmp_known_var_weights, axis=1)

        return tmp_known_envs, tmp_known_mean_weights, tmp_known_var_weights, tmp_mu, tmp_noise_var

    # Function to compute the covariance matrix in the form Caa, Cab, Cba, Cbb
    def compute_cov_matrix(self, ne_characteristic_vector, ke_characteristic_vectors):
        _Caa = np.array(self.kernel(ne_characteristic_vector, ne_characteristic_vector)).reshape((1, 1))
        _Cab = np.zeros((1, ke_characteristic_vectors.shape[1]))
        for known_env_index in range(ke_characteristic_vectors.shape[1]):
            _Cab[0, known_env_index] = self.kernel(ne_characteristic_vector, ke_characteristic_vectors[:, known_env_index])
        _Cba = _Cab.T
        _Cbb = np.zeros((ke_characteristic_vectors.shape[1], ke_characteristic_vectors.shape[1]))
        for index1 in range(ke_characteristic_vectors.shape[1]):
            _Cbb[index1, index1] = self.kernel(ke_characteristic_vectors[:, index1], ke_characteristic_vectors[:, index1])
            for index2 in range(index1 + 1, ke_characteristic_vectors.shape[1]):
                _Cbb[index1, index2] = _Cbb[index2, index1] = self.kernel(ke_characteristic_vectors[:, index1],
                                                                     ke_characteristic_vectors[:, index2])
        return _Caa, _Cab, _Cba, _Cbb

    # Kernel function
    def kernel(self, x, y):
        return np.exp(-1 * (x - y).T @ (x - y))  # squared exponential