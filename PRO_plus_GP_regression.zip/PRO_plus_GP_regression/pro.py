### PRO ###
import numpy as np

# Represents a learnt optimal policy
class Learnt_pol:

    def __init__(self, all_objective_vals, mu_w, var_w):
        self.all_objective_vals = all_objective_vals
        self.mu_w = mu_w
        self.var_w = var_w


# Optimizes distribution of trajectories using PRO
def optimize(dofs, env, n_iter, n_samples, max_length, num_gaba, block_PSI, mu_w, var_w, sample_trajectories, get_target, beta=10):

    start_cartesian = np.array([0, 0])

    n_relfun = 3  # Number of relevance functions. There is one for each objective.

    start = [n * max_length for n in range(dofs)]  # Indices for the values of DoFs at the start of a trajectory
    end = [n * max_length - 1 for n in range(1, dofs + 1)]  # Indices for the values of DoFs at the end of a trajectory

    new_Sigma = np.diag(var_w.reshape(-1, )) * 0

    relevance = None

    reward_weight = 0

    epsilon = 0.001  # For detecting convergence
    sliding_window_size = 5  # For detecting convergence
    converged = False

    all_objective_vals = [np.zeros((n_samples, n_iter)) for i in
                          range(n_relfun)]  # list with n_relfun matrices of shape = (n_samples, n_iters)
    # A value is computed for each objective, sample and iteration.

    for iteration in range(n_iter):
        print(iteration)

        # Verify convergence and if solution is good enough
        if iteration >= sliding_window_size:
            converged = True
            for rel_fun in range(n_relfun):
                current_objective_vals = all_objective_vals[rel_fun]
                objectives_window = current_objective_vals[:, iteration - sliding_window_size:iteration]
                max_val = np.max(objectives_window)
                min_val = np.min(objectives_window)
                if max_val - min_val > epsilon:
                    converged = False

                # if rel_fun == 1:
                #     max_objective_val = np.max(current_objective_vals[:, iteration - 1])
                #     if max_objective_val > - 0.6:  # 0.6 m is the minimum distance I want the robot and the human to keep from each other
                #         converged = False

        if converged:
            print('Convergence achieved')
            # prune all_objective_vals
            for rel_fun in range(n_relfun):
                all_objective_vals[rel_fun] = all_objective_vals[rel_fun][:, 0:iteration]
            break

        relevance = learn_relevances(n_relfun, dofs, env, sample_trajectories, n_samples, mu_w, var_w, num_gaba, block_PSI, start, end, get_target)

        # Iterate over the number of relevance functions
        for rel_fun in range(n_relfun):

            previous_var_w = var_w.reshape(-1, )

            weights_rel = var_w.reshape(-1, ) * relevance[:, rel_fun]  # Compute variances with relevance function.

            weight_samples, traj_samples = sample_trajectories(n_samples, mu_w, weights_rel.reshape(-1, 1), dofs, num_gaba, block_PSI)  # Sample weights and trajectories using rescaled variances.

            if rel_fun == 0:  # Relevance with respect to distance to the start Cartesian position
                objective_val = compute_dist_to_start(traj_samples, start_cartesian, start)

            elif rel_fun == 1:  # Relevance with respect to the minimum distance to the human
                objective_val = -compute_dist_to_human(dofs, traj_samples, env)

            elif rel_fun == 2:  # Relevance with respect to distance to the target
                objective_val = compute_dist_to_target(traj_samples, env, end, get_target)

            # Append current objective value
            all_objective_vals[rel_fun][:, iteration] = objective_val.reshape(n_samples, )

            # This is to avoid making the robot go too far away from the human
            if rel_fun == 1:
                objective_val[objective_val <= -1.9] = -1.9  # Because the target is at 2m of distance from the human

            # Take into consideration the average deviation from the direct way to the goal
            objective_val += compute_avg_distance_to_the_way_to_goal(dofs, traj_samples, start_cartesian, env, get_target)

            R = -objective_val

            reward_weight = np.exp(beta * R)  # (n_samples, 1)

            # Update distribution
            new_mu_w = np.dot(np.transpose(weight_samples), reward_weight)  # (N*dofs, 1) = (N*dofs, n_samples) * (n_samples, 1)
            W_minus_mu = np.subtract(weight_samples, np.transpose(mu_w))  # (n_samples, N*dofs)
            new_Sigma = new_Sigma * 0  # (N*dofs, N*dofs)

            for i in range(n_samples):
                new_Sigma = new_Sigma + reward_weight[i] * W_minus_mu[i, :].T * W_minus_mu[i, :]

            new_mu_w = new_mu_w / np.sum(reward_weight)
            new_Sigma = new_Sigma / np.sum(reward_weight)

            mu_w = new_mu_w
            Sigma_w = new_Sigma
            Sigma_w = (Sigma_w + Sigma_w.T) / 2  # To make sure Sigma_w is symmetric

            updated_var_w = (1 - relevance[:, rel_fun]) * previous_var_w + \
                relevance[:, rel_fun] * np.diag(Sigma_w)
            var_w = updated_var_w.reshape(-1, 1)


    return Learnt_pol(all_objective_vals, mu_w, var_w), converged


# Learns relevance functions
def learn_relevances(n_relfun, dofs, env, sample_trajectories, n_samples, mu_w, var_w, n_gbf, block_PSI, start, end, get_target):
    # Sample weights and trajectories
    # trajectory samples: n_samples x max_length*dofs
    variances = var_w * 0 + 1e-5
    weight_samples, traj_samples = sample_trajectories(n_samples, mu_w, variances, dofs, n_gbf, block_PSI)

    start_cartesian = np.array([0, 0])

    # Compute the distance to the start Cartesian position (0, 0), the min. distance to the human and the distance to the target.
    objective_vals = []
    for rel_fun in range(n_relfun):
        if rel_fun == 0:  # Relevance with respect to distance to the start Cartesian position
            curr_objective_val = compute_dist_to_start(traj_samples, start_cartesian, start)
        elif rel_fun == 1:  # Relevance with respect to the minimum distance to the human
            curr_objective_val = -compute_dist_to_human(dofs, traj_samples, env)
        elif rel_fun == 2:  # Relevance with respect to distance to the target
            curr_objective_val = compute_dist_to_target(traj_samples, env, end, get_target)

        # Take into consideration the the average deviation from the direct way to the goal
        curr_objective_val += compute_avg_distance_to_the_way_to_goal(dofs, traj_samples, start_cartesian, env, get_target)

        objective_vals = curr_objective_val if objective_vals == [] else np.hstack((objective_vals, curr_objective_val))  # (n_samples, number of objectives)

    # Compute Pearson correlation coefficient
    cols_w = weight_samples.shape[1]  # N*dofs
    cols_d = objective_vals.shape[1]  # number of objectives
    relevances = np.zeros((cols_w, cols_d))  # (N*dofs, number of objectives)
    for i in range(cols_w):  # for each weight
        for j in range(cols_d): # for each objective
            relevances[i][j] = np.corrcoef(weight_samples[:, i], objective_vals[:, j], rowvar=False)[0][1]  # QUESTION: Is it possible to vectorize this to get rid of the loop?
    # Normalize s.t. biggest value is 1
    relevances = np.abs(relevances)
    # relevances = relevances / relevances.max(axis=0)

    #print("Done calculating relevances")
    return relevances


# Computes the distances between the sample trajectories and the start Cartesian position
def compute_dist_to_start(traj_samples, start_cartesian, start):

    dist = traj_samples[:, start] - start_cartesian
    dist = np.sqrt(np.sum(dist ** 2, axis=1))

    return dist.reshape(len(dist), 1)  # (n_samples, 1)


# Computes the minimum Euclidean distance between each sampled trajectory and the human
def compute_dist_to_human(dofs, traj_samples, env):

    n_samples = traj_samples.shape[0]
    max_length = int(traj_samples.shape[1] / dofs)
    distances = np.zeros((n_samples, 1))
    human_xy = env[0:2]

    for sample_index in range(n_samples):
        cartesian = traj_samples[sample_index, :].reshape((max_length, dofs), order='F')
        min_dist = np.Inf
        for t in range(max_length):
            dist = np.linalg.norm(cartesian[t, 0:2] - human_xy)
            if dist < min_dist:
                min_dist = dist
                distances[sample_index, 0] = dist

    return distances


# Computes the distances between the sample trajectories and the target
def compute_dist_to_target(traj_samples, env, end, get_target):
    n_samples = traj_samples.shape[0]
    distances = np.zeros((n_samples, 1))
    human_xy = env[0:2]
    human_theta = env[-1]
    target = get_target(human_xy[0], human_xy[1], human_theta)

    for sample_index in range(n_samples):
        last_cartesian = traj_samples[sample_index, end]
        dist = np.linalg.norm(last_cartesian[0:2] - target)
        distances[sample_index, 0] = dist

    return distances


# # Computes the average magnitude of the jerk for each sample trajectory
# def compute_avg_jerk_magnitude(dofs, traj_samples):
#
#     n_samples = traj_samples.shape[0]
#     max_length = int(traj_samples.shape[1] / dofs)
#     avg_jerk_magnitudes = np.zeros((n_samples, 1))
#
#     for sample_index in range(n_samples):
#         joint = traj_samples[sample_index, :].reshape((max_length, dofs), order='F')
#         jerk = np.diff(joint, n=3, axis=0)
#         jerk_magnitude = np.sqrt(np.sum(jerk ** 2, axis=1))
#         avg_jerk_magnitudes[sample_index, 0] = np.mean(jerk_magnitude)
#
#     return avg_jerk_magnitudes


# Computes the average distance to the direct way to the goal
def compute_avg_distance_to_the_way_to_goal(dofs, traj_samples, start_cartesian, env, get_target):

    n_samples = traj_samples.shape[0]
    max_length = int(traj_samples.shape[1] / dofs)
    avg_distances = np.zeros((n_samples, 1))
    human_xy = env[0:2]
    human_theta = env[-1]
    target = get_target(human_xy[0], human_xy[1], human_theta)

    direct_way = np.zeros((max_length, dofs))
    direct_way[:, 0] = np.linspace(start_cartesian[0], target[0], max_length)
    direct_way[:, 1] = np.linspace(start_cartesian[1], target[1], max_length)

    for sample_index in range(n_samples):
        cartesian = traj_samples[sample_index, :].reshape((max_length, dofs), order='F')
        avg_dist = 0
        for t in range(max_length):
            avg_dist += np.linalg.norm(cartesian[t, :] - direct_way[t, :])
        avg_dist = avg_dist/max_length
        avg_distances[sample_index, 0] = avg_dist

    return avg_distances
