########### Import libraries ########################################################

import numpy as np
import matplotlib.pyplot as plt
import learn_ProMP_from_demonstrations as lpd
from numpy.linalg import inv
import pro
import timeit
import plot_pro_res

tic = timeit.default_timer()


########### Set random seed #########################################################

np.random.seed(0)


########### Set number of basis functions of the ProMPs #############################

num_gaba = 10  # Number of Gaussian basis functions

n_demonstrated_envs = 30
n_demonstrations_per_env = 3


########### Determine ProMP based on the demonstrations #############################

promp_from_demonstration = lpd.learn_promp(num_gaba, n_demonstrated_envs, n_demonstrations_per_env)

n_dof = 2

known_mean_weights = np.zeros((n_dof*num_gaba, n_demonstrated_envs))
for i in range(n_demonstrated_envs):
    known_mean_weights[:, i] = np.mean(promp_from_demonstration.weight_matrix[:, n_demonstrations_per_env*i:n_demonstrations_per_env*i + n_demonstrations_per_env], axis=1)

known_var_weights = np.zeros((n_dof*num_gaba, n_demonstrated_envs))
for i in range(n_demonstrated_envs):
    known_var_weights[:, i] = np.var(promp_from_demonstration.weight_matrix[:, n_demonstrations_per_env*i:n_demonstrations_per_env*i + n_demonstrations_per_env], axis=1)

noise_var = np.mean(known_var_weights, axis=1)  # average variance for each weight based on the demonstrations
original_noise_var = np.copy(noise_var)


########### Load Learned Model ######################################################

n_dof = 2

# Load learned model
learned_model_folder = "Learned_Model"
known_envs = np.load(learned_model_folder + '/known_envs.npy')
ke_characteristic_vectors = np.load(learned_model_folder + '/ke_characteristic_vectors.npy')
known_envs_groups = np.load(learned_model_folder + '/known_envs_groups.npy')
really_known_envs = np.load(learned_model_folder + '/really_known_envs.npy')
rke_characteristic_vectors = np.load(learned_model_folder + '/rke_characteristic_vectors.npy')
really_known_envs_groups = np.load(learned_model_folder + '/really_known_envs_groups.npy')
unknown_envs = np.load(learned_model_folder + '/unknown_envs.npy')
ue_characteristic_vectors = np.load(learned_model_folder + '/ue_characteristic_vectors.npy')
unknown_envs_groups = np.load(learned_model_folder + '/unknown_envs_groups.npy')
known_mean_weights = np.load(learned_model_folder + '/known_mean_weights.npy')
really_known_mean_weights = np.load(learned_model_folder + '/really_known_mean_weights.npy')
known_var_weights = np.load(learned_model_folder + '/known_var_weights.npy')
really_known_var_weights = np.load(learned_model_folder + '/really_known_var_weights.npy')
mu = np.load(learned_model_folder + '/mu.npy')
noise_var = np.load(learned_model_folder + '/noise_var.npy')
max_length = np.load(learned_model_folder + '/max_length.npy')
block_PSI = np.load(learned_model_folder + '/block_PSI.npy')
num_gaba = np.load(learned_model_folder + '/num_gaba.npy')
unsolved_envs = np.load(learned_model_folder + '/unsolved_envs.npy')
unsolved_envs_indexes = np.load(learned_model_folder + '/unsolved_envs_indexes.npy')
unsolved_envs_groups = np.load(learned_model_folder + '/unsolved_envs_groups.npy')


############ Corners ###############################################################

corners = np.array([[0, 0], [10, 0], [10, 10], [0, 10]])

x_min_corners = np.min(corners[:, 0])
x_max_corners = np.max(corners[:, 0])
y_min_corners = np.min(corners[:, 1])
y_max_corners = np.max(corners[:, 1])


###########
def get_target(hx, hy, htheta, dist_to_target=2):
    target_x = hx + dist_to_target * np.cos(htheta)
    target_y = hy + dist_to_target * np.sin(htheta)
    target = np.array([target_x, target_y])
    return target
###########


# Function to compute the characteristic vector of an environment
# The characteristic vector of an environment is the concatenation of the vectors robot_to_human
# and robot_to_target
def get_characteristic_vector(env):
    robot_pos = np.array([0, 0])
    human_xy = env[0:2]
    human_theta = env[-1]
    target = get_target(human_xy[0], human_xy[1], human_theta)

    robot_to_human = human_xy - robot_pos
    robot_to_target = target - robot_pos

    characteristic_vector = np.hstack((robot_to_human, robot_to_target))

    return characteristic_vector


###########
# Function to determine the group of the environment. There are two groups: 1) The human is to the left of the direct path to the target.
# 2) The human is to the right of the direct path to the target.
def what_group(env):
    robot_pos = np.array([0, 0])
    human_xy = env[0:2]
    human_theta = env[-1]
    target = get_target(human_xy[0], human_xy[1], human_theta)

    robot_to_human = human_xy - robot_pos
    robot_to_target = target - robot_pos

    cross_product = np.cross(robot_to_target, robot_to_human)

    if cross_product >= 0:
        return 1
    else:
        return 2
############


############
# Function to determine the group of the environment given a solution to that environment
def what_group_given_solution(env, _trajectory):

    T = int(_trajectory.shape[0]/2)

    trajectory = np.copy(_trajectory)
    trajectory = trajectory.reshape((T, -1), order='F')

    human_xy = env[0:2]
    target = get_target(human_xy[0], human_xy[1], env[-1])
    robot_pos = np.array([0, 0])

    robot_to_human = human_xy - robot_pos
    robot_to_target = target - robot_pos

    # projection of robot_to_human on robot_to_target
    tmp = np.dot(robot_to_human, robot_to_target)/np.dot(robot_to_target, robot_to_target)
    p_rh_on_rt = tmp * robot_to_target

    vec_b = (robot_pos + p_rh_on_rt) - human_xy

    interest_point = None
    min_abs_cross_prod = np.Inf
    for i in range(trajectory.shape[0]):
        traj_point = trajectory[i, :]
        vec_a = traj_point - human_xy
        abs_cross_prod = np.abs(np.cross(vec_a, vec_b))
        if abs_cross_prod < min_abs_cross_prod:
            min_abs_cross_prod = abs_cross_prod
            interest_point = traj_point

    # vector from robot to "interesting" point
    robot_to_interest_point = interest_point - robot_pos

    cross_product = np.cross(robot_to_human, robot_to_interest_point)

    if cross_product >= 0:
        return 2, interest_point
    else:
        return 1, interest_point

############


########### Functions ###############################################################

def create_circle(center, r):
    circle= plt.Circle(center, radius=r, color='r')
    return circle


# Kernel function
def kernel(x, y):
    return np.exp(-1*(x-y).T @ (x-y))  # squared exponential


# Function to sample a new random environment
def sample_new_env(ue_characteristic_vectors, ke_characteristic_vectors, unknown_envs, unknown_envs_groups, known_envs_groups):

    min_min_dist = np.Inf
    index = 0
    new_rand_env = unknown_envs[:, 0]

    for i in range(unknown_envs.shape[1]):

        # Two environments are similar if the vectors robot_to_human and robot_to_target are similar
        # and if both environments belong to the same group.
        ue_characteristic_vector = ue_characteristic_vectors[:, i].reshape((-1, 1))

        diffs = ke_characteristic_vectors - ue_characteristic_vector

        dists = np.linalg.norm(diffs, axis=0)
        dists[np.array(known_envs_groups) != unknown_envs_groups[i]] = np.Inf
        min_dist = min(dists)
        if min_dist < min_min_dist:
            min_min_dist = min_dist
            new_rand_env = unknown_envs[:, i]
            index = i


    print('Nr. of unknown envs. = {}'.format(unknown_envs.shape[1]))
    print('Min. min. distance = {}'.format(min_min_dist))

    return new_rand_env, index


# Function to find the N closest known environments to a given environment
def find_closest_envs(ke_characteristic_vectors, known_envs, known_mean_weights, known_var_weights, new_env, new_env_group, known_envs_groups, N=30):

    ne_characteristic_vector = get_characteristic_vector(new_env)

    diffs = ke_characteristic_vectors - ne_characteristic_vector.reshape(-1, 1)
    dists = np.linalg.norm(diffs, axis=0)

    dists[np.array(known_envs_groups) != new_env_group] = np.Inf

    indices = np.argsort(dists)

    tmp_known_envs = known_envs[:, indices[:N]]
    tmp_known_mean_weights = known_mean_weights[:, indices[:N]]
    tmp_known_var_weights = known_var_weights[:, indices[:N]]

    tmp_mu = np.mean(tmp_known_mean_weights, axis=1)
    tmp_noise_var = np.mean(tmp_known_var_weights, axis=1)

    return tmp_known_envs, tmp_known_mean_weights, tmp_known_var_weights, tmp_mu, tmp_noise_var


# Function to compute the covariance matrix in the form Caa, Cab, Cba, Cbb
def compute_cov_matrix(ne_characteristic_vector, ke_characteristic_vectors):
    _Caa = np.array(kernel(ne_characteristic_vector, ne_characteristic_vector)).reshape((1, 1))
    _Cab = np.zeros((1, ke_characteristic_vectors.shape[1]))
    for known_env_index in range(ke_characteristic_vectors.shape[1]):
        _Cab[0, known_env_index] = kernel(ne_characteristic_vector, ke_characteristic_vectors[:, known_env_index])
    _Cba = _Cab.T
    _Cbb = np.zeros((ke_characteristic_vectors.shape[1], ke_characteristic_vectors.shape[1]))
    for index1 in range(ke_characteristic_vectors.shape[1]):
        _Cbb[index1, index1] = kernel(ke_characteristic_vectors[:, index1], ke_characteristic_vectors[:, index1])
        for index2 in range(index1 + 1, ke_characteristic_vectors.shape[1]):
            _Cbb[index1, index2] = _Cbb[index2, index1] = kernel(ke_characteristic_vectors[:, index1], ke_characteristic_vectors[:, index2])
    return _Caa, _Cab, _Cba, _Cbb


# Function to plot the environment
def plot_environment(env, corners):
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.grid(True)
    ax.set_xlim(-3, 13)
    ax.set_ylim(-3, 13)
    # ax.set_xlim(-5, 15)
    # ax.set_ylim(-5, 15)

    # Draw walls
    ax.plot([corners[0, 0], corners[1, 0]], [corners[0, 1], corners[1, 1]], linewidth=2.0, color="b")
    ax.plot([corners[1, 0], corners[2, 0]], [corners[1, 1], corners[2, 1]], linewidth=2.0, color="b")
    ax.plot([corners[2, 0], corners[3, 0]], [corners[2, 1], corners[3, 1]], linewidth=2.0, color="b")
    ax.plot([corners[3, 0], corners[0, 0]], [corners[3, 1], corners[0, 1]], linewidth=2.0, color="b")

    robot_pos = np.array([0, 0])
    human_xy = env[0:2]
    human_theta = env[-1]
    target = get_target(human_xy[0], human_xy[1], human_theta)

    ax.scatter(robot_pos[0], robot_pos[1], color='g', marker='o', label='robot')

    ax.scatter(human_xy[0], human_xy[1], color='r', label='human')

    c = create_circle((human_xy[0], human_xy[1]), 0.6)

    ax.add_patch(c)
    plt.axis('equal')

    ax.scatter(target[0], target[1], color='k', marker='x', label='target')

    ax.set_xlabel('x')
    ax.set_ylabel('y')

    return fig, ax


# Function to sample trajectories
def sample_trajectories(n_samples, mu_w, var_w, n_dof, n_gbf, block_PSI):
    _weight_samples = np.random.multivariate_normal(mu_w.reshape((mu_w.size,)),
                                                   np.diag(var_w.reshape(n_dof*n_gbf, )), n_samples)
    # shape = (n_samples, dofs*max_length)
    _traj_samples = np.dot(_weight_samples, np.transpose(block_PSI))
    return _weight_samples, _traj_samples


# Functions related to recording new trajectories

pressed = False
trajectory_x, trajectory_y = [], []


def on_press(event):
    global pressed
    pressed = True


def on_move(event):
    global pressed
    global trajectory_x
    global trajectory_y
    global line
    if pressed:
        trajectory_x.append(event.xdata)
        trajectory_y.append(event.ydata)
        line.set_data(trajectory_x, trajectory_y)
        line.figure.canvas.draw()


def on_release(event):
    global pressed
    global trajectory_x
    global trajectory_y
    global traj_count

    pressed = False
    trajectory = np.array([trajectory_x, trajectory_y])

    file_name = "new_demonstrations/traj"+str(traj_count)+".out"
    np.savetxt(file_name, trajectory.T, delimiter=',')

    traj_count += 1

    # Reset current trajectory
    trajectory_x, trajectory_y = [], []

########### Main code #############################################################

n_samples = 100
n_iter = 100  # Maximum number of iterations. PRO may reach convergence before that.

T = promp_from_demonstration.max_length

# for each new random environment, infer w with mean and standard deviation

new_mean_weights = np.zeros((n_dof*num_gaba, 1))
new_var_weights = np.zeros((n_dof*num_gaba, 1))

print("Number of unsolved environments = {}".format(unsolved_envs.shape[1]))

for i in range(unsolved_envs.shape[1]):

    print('New environment {}'.format(i))

    # get a new unsolved environment
    new_env = unsolved_envs[:, i]

    ne_characteristic_vector = get_characteristic_vector(new_env)

    ## Figure out if the object is to the left or to the right of the direct path to the goal
    new_env_group = unsolved_envs_groups[i]

    ## Find the closest envs
    tmp_known_envs, tmp_known_mean_weights, tmp_known_var_weights, tmp_mu, tmp_noise_var = find_closest_envs(ke_characteristic_vectors, known_envs, known_mean_weights, known_var_weights, new_env, new_env_group, known_envs_groups)

    tmp_ke_characteristic_vectors = np.zeros((4, tmp_known_envs.shape[1]))
    for j in range(tmp_known_envs.shape[1]):
        tmp_ke_characteristic_vector = get_characteristic_vector(tmp_known_envs[:, j])
        tmp_ke_characteristic_vectors[:, j] = tmp_ke_characteristic_vector

    # Keep the observation noise high for exploration purposes
    tmp_noise_var = original_noise_var

    for w_index in range(n_dof * num_gaba):  # There is one GP for each weight
        Caa, Cab, Cba, Cbb = compute_cov_matrix(ne_characteristic_vector, tmp_ke_characteristic_vectors)
        yb = tmp_known_mean_weights[w_index, :].reshape(tmp_known_envs.shape[1], 1)
        w_var_matrix = np.diag(tmp_known_var_weights[w_index, :])
        # Inference
        m = tmp_mu[w_index] + Cab @ inv(Cbb + w_var_matrix) @ (yb - tmp_mu[w_index])  # mu_a = mu_b = mu[w_index]
        D = Caa + tmp_noise_var[w_index] - Cab @ inv(Cbb + w_var_matrix) @ Cba
        new_mean_weights[w_index] = m
        new_var_weights[w_index] = D

    # Save GP inference
    np.save('GP_inferences_2/ms_{}'.format(i), new_mean_weights)
    np.save('GP_inferences_2/Ds_{}'.format(i), new_var_weights)
    np.save('GP_inferences_2/env_{}'.format(i), new_env)


    # Visualize GP inference

    # print(ne_characteristic_vector.shape)

    # plot new environment
    fig, ax = plot_environment(new_env, corners)
    # sample trajectories from the posterior computed with GP regression
    weight_samples, traj_samples = sample_trajectories(n_samples, new_mean_weights, new_var_weights, n_dof, num_gaba,
                                                       promp_from_demonstration.block_PSI)

    # # plot sampled trajectories
    # for sample_index in range(n_samples):
    #     ax.plot(traj_samples[sample_index, 0:T], traj_samples[sample_index, T:2*T], color='0.7')
    #
    # # compute mean trajectory of posterior
    # mean_trajectory = np.dot(new_mean_weights.reshape(-1, ), np.transpose(promp_from_demonstration.block_PSI))
    # mean_trajectory = mean_trajectory.reshape(1, -1)
    #
    # # plot the mean trajectory of posterior
    # ax.plot(mean_trajectory[0, 0:T], mean_trajectory[0, T:2 * T], 'b', label='Mean of posterior')
    #
    # ax.plot([0, ne_characteristic_vector[0]], [0, ne_characteristic_vector[1]], 'c')
    # ax.plot([0, ne_characteristic_vector[2]], [0, ne_characteristic_vector[3]], 'm')
    #
    plt.show()

    # # Optimize inference using PRO
    # learnt_pol, converged = pro.optimize(n_dof, new_env, n_iter, n_samples,
    #                                           promp_from_demonstration.max_length, num_gaba,
    #                                           promp_from_demonstration.block_PSI, new_mean_weights, new_var_weights,
    #                                           sample_trajectories, get_target)
    # new_mean_weights = learnt_pol.mu_w
    # new_var_weights = learnt_pol.var_w
    #
    # # compute the mean trajectory of the optimized distribution
    # mean_trajectory = np.dot(new_mean_weights.reshape(-1, ), np.transpose(promp_from_demonstration.block_PSI))
    # mean_trajectory = mean_trajectory.reshape(1, -1)
    #
    # # # Plot PRO iterations vs returns
    # # plot_pro_res.plot(3, learnt_pol.all_objective_vals[0].shape[1], promp_from_demonstration.max_length,
    # #                    learnt_pol)
    #
    # # sample trajectories from the optimized distribution
    # weight_samples, traj_samples = sample_trajectories(n_samples, new_mean_weights, new_var_weights, n_dof,
    #                                                    num_gaba, promp_from_demonstration.block_PSI)
    #
    # # plot new environment
    # fig, ax = plot_environment(new_env, corners)
    #
    # # plot sampled trajectories
    # for sample_index in range(n_samples):
    #     ax.plot(traj_samples[sample_index, 0:T], traj_samples[sample_index, T:2 * T], color='0.7')
    #
    # # plot the mean trajectory of posterior
    # ax.plot(mean_trajectory[0, 0:T], mean_trajectory[0, T:2 * T], 'b', label='Mean of optimized distribution')
    #
    # plt.show()


    # if converged:
    #     env_index = unsolved_envs_indexes[i]
    #     known_envs[:, env_index] = new_env
    #     ke_characteristic_vectors[:, env_index] = ne_characteristic_vector
    #     known_mean_weights[:, env_index] = new_mean_weights.reshape(-1, )
    #     known_var_weights[:, env_index] = new_var_weights.reshape(-1, )
    #
    #     ## Determine the group of this environment based on the solution found by PRO
    #     known_envs_groups[i], interest_point = what_group_given_solution(new_env, mean_trajectory[0, :2*T])
    #     print("Group of this environment = {}".format(known_envs_groups[i]))
    #     ##
    #
    #     really_known_envs = np.hstack((really_known_envs, new_env.reshape((-1, 1))))
    #     rke_characteristic_vectors = np.hstack((rke_characteristic_vectors, ne_characteristic_vector.reshape((-1, 1))))
    #     really_known_mean_weights = np.hstack((really_known_mean_weights, new_mean_weights.reshape((-1, 1))))
    #     really_known_var_weights = np.hstack((really_known_var_weights, new_var_weights.reshape((-1, 1))))
    #
    #     #really_known_envs_groups.append(new_env_group)
    #
    #     ## Determine the group of this environment based on the solution found by PRO
    #     tmp, interest_point = what_group_given_solution(new_env, mean_trajectory[0, :2*T])
    #     really_known_envs_groups.append(tmp)
    #     ##
    #
    #
    #     noise_var = np.mean(known_var_weights, axis=1)
    #     mu = np.mean(known_mean_weights, axis=1)
    #
    #     # ax.scatter(interest_point[0], interest_point[1], color='r', label='interesting point')
    #
    #
    # # plt.show()
    #
    # # Save Learned Model
    # learned_model_folder = "Learned_Model"
    # np.save(learned_model_folder + '/known_envs', known_envs)
    # np.save(learned_model_folder + '/ke_characteristic_vectors', ke_characteristic_vectors)
    # np.save(learned_model_folder + '/known_envs_groups', known_envs_groups)
    # np.save(learned_model_folder + '/really_known_envs', really_known_envs)
    # np.save(learned_model_folder + '/rke_characteristic_vectors', rke_characteristic_vectors)
    # np.save(learned_model_folder + '/really_known_envs_groups', really_known_envs_groups)
    # np.save(learned_model_folder + '/unknown_envs', unknown_envs)
    # np.save(learned_model_folder + '/ue_characteristic_vectors', ue_characteristic_vectors)
    # np.save(learned_model_folder + '/unknown_envs_groups', unknown_envs_groups)
    # np.save(learned_model_folder + '/known_mean_weights', known_mean_weights)
    # np.save(learned_model_folder + '/really_known_mean_weights', really_known_mean_weights)
    # np.save(learned_model_folder + '/known_var_weights', known_var_weights)
    # np.save(learned_model_folder + '/really_known_var_weights', really_known_var_weights)
    # np.save(learned_model_folder + '/mu', mu)
    # np.save(learned_model_folder + '/noise_var', noise_var)
    # np.save(learned_model_folder + '/max_length', promp_from_demonstration.max_length)
    # np.save(learned_model_folder + '/block_PSI', promp_from_demonstration.block_PSI)
    # np.save(learned_model_folder + '/num_gaba', num_gaba)
    # np.save(learned_model_folder + '/unsolved_envs', unsolved_envs)
    # np.save(learned_model_folder + '/unsolved_envs_indexes', unsolved_envs_indexes)
    # np.save(learned_model_folder + '/unsolved_envs_groups', unsolved_envs_groups)

toc = timeit.default_timer()
print(toc - tic)


