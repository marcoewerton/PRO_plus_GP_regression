## This script executes trajectories of the robot for given scenarios

from __future__ import print_function
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import animation
import myClasses as mC
import seaborn as sns
sns.set()


############################# Parameters ################################
n_envs = 30
n_dems_per_env = 3



############################# Functions #################################




############################# Main code ##################################

corners = np.array([[0, 0], [10, 0], [10, 10], [0, 10]])

envs = np.load('dem_envs/dem_envs.npy')

for i in range(n_envs):
    for j in range(n_dems_per_env):

        robot_trajectory = np.load('demonstrations/dem_{}_{}.npy'.format(i, j))

        fig, ax = plt.subplots(figsize=(7, 7))
        plt.axis('scaled')
        ax.set_xlim(-3, 13)
        ax.set_ylim(-3, 13)

        ax.set_title('Environment {}, demonstration {}'.format(i, j))
        print('Environment {}, demonstration {}'.format(i, j))

        # Draw walls
        ax.plot([corners[0, 0], corners[1, 0]], [corners[0, 1], corners[1, 1]], linewidth=2.0, color="b")
        ax.plot([corners[1, 0], corners[2, 0]], [corners[1, 1], corners[2, 1]], linewidth=2.0, color="b")
        ax.plot([corners[2, 0], corners[3, 0]], [corners[2, 1], corners[3, 1]], linewidth=2.0, color="b")
        ax.plot([corners[3, 0], corners[0, 0]], [corners[3, 1], corners[0, 1]], linewidth=2.0, color="b")

        # Initialize human
        h_center = envs[i, 0:2]
        h_radius = 0.25
        h_color = "r"
        h_angle = envs[i, 2]
        # print(h_angle)
        h_dist_to_target = 2
        human = mC.Human(h_center, h_radius, h_color, h_angle, h_dist_to_target, ax, corners)

        # Initialize robot
        r_center = envs[i, 3:5]
        r_radius = 0.25
        r_color = "g"

        # Initialize mouse
        mouse = mC.Mouse(ax)

        robot_to_human = h_center - r_center

        r_angle = np.arctan2(robot_to_human[1], robot_to_human[0])
        r_arrow_length = 1
        robot = mC.Robot(r_center, r_radius, r_color, r_angle, r_arrow_length, ax, corners)

        # Initialize animator
        animator = mC.Animator(human, robot, mouse, trajectory=robot_trajectory)

        anim = animation.FuncAnimation(fig, animator.animate,
                                       init_func=animator.init,
                                       frames=100000,
                                       interval=20,
                                       blit=True)

        plt.show()


